<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8 col-md-offset-2">
                <div class="panel panel-primary">
                    <div class="panel-heading"><?php echo e($post->title); ?></div>

                    <div class="panel-body">
                        <p><?php echo e($post->content); ?></p>
                    </div>
                </div>

                <div class="panel panel-default">
                    <div class="panel-heading"><?php echo e($post->comments()->count()); ?> Komentar</div>
                    <?php $__currentLoopData = $post->comments()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="panel-body">
                            <h3><?php echo e($comment->user->name); ?> - <small><?php echo e($comment->created_at); ?></small></h3>
                            <p><?php echo e($comment->message); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="panel-heading">Tambahkan Komentar</div>

                    <div class="panel-body">
                        <form class="form-horizontal has-feedback<?php echo e($errors->has('message') ? ' has-error' : ''); ?>" action="<?php echo e(route('post.comment.store', $post)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <textarea class="form-control" name="message" rows="3" placeholder="Berikan Komentar..."><?php echo e(old('message')); ?></textarea>
                            <?php if($errors->has('message')): ?>
                                <span class="help-block">
                                    <p><?php echo e($errors->first('message')); ?></p>
                                </span>
                            <?php endif; ?>
                            <input type="submit" value="Tambah Komentar" class="btn btn-primary" style="margin-top:15px;">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>